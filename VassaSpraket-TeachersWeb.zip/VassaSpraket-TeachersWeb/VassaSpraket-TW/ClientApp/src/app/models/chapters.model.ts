export class ChaptersViewModel{
  id: number;
  chapterName: string;
  chapterNumber: number;  
}
