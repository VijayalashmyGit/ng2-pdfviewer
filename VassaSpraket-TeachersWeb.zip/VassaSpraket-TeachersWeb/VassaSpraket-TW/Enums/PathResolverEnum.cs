﻿
namespace VassaSpraket_TW.Enums
{

    public enum PathResolverEnum {
        PageTemplate       
    }
}
