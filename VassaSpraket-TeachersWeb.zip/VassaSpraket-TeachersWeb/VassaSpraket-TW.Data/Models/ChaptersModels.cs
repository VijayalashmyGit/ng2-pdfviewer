﻿namespace VassaSpraket_TW.Data.Models
{
    public class Chapters
    {
        public int Id { get; set; }
        public string ChapterName { get; set; }
        public int ChapterNumber { get; set; }
      
    }

   
}
